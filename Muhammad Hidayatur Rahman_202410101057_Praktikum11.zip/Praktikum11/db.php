<?php

const DB_HOST = 'localhost';
const DB_USER = '202410101057';
const DB_PASS = 'secret';
const DB_NAME = 'uas202410101057';

?>